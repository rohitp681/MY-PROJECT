<?php
session_start();
require 'dp.php';

$pwd = $_POST['password'];
$fname = $_POST['firstname'];
$lname = $_POST['lastname'];
$email = $_POST['email'];

// Gmail validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/@gmail\.com$/i', $email)) {
    echo "Invalid Gmail address.";
    exit();
}

$sql = "INSERT INTO patientlogin(email, password, firstname, lastname) VALUES ('$email', '$pwd', '$fname', '$lname')";
$res = mysqli_query($con, $sql);

if (!$res) {
    echo "Error Occurred";
    header('Location: ../html/patientlogin.php');
    exit();
} else {
    $_SESSION['pemail'] = $email;
    echo "Inserted Successfully";
    header('Location: ../html/user_form.php');
    exit();
}
?>
